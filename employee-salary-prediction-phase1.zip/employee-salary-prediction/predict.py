"""Salary inference: load the trained bundle, validate a profile, predict.

All validation happens here (server side) so the Flask routes, the CSV import,
and the tests share one set of rules.
"""
from __future__ import annotations

import logging
import math
import os
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd

import features as F

log = logging.getLogger(__name__)
DEFAULT_MODEL_PATH = Path(__file__).resolve().parent / "models" / "salary_model.joblib"

_cache: dict[str, dict] = {}

FIELD_LABELS = {
    "experience_years": "Experience", "education": "Education", "job_title": "Job title",
    "department": "Department", "company_size": "Company size",
    "employment_type": "Employment type", "location": "Location", "industry": "Industry",
}


class ModelNotAvailableError(RuntimeError):
    """Raised when the model file is missing or cannot be loaded."""


class ProfileValidationError(ValueError):
    def __init__(self, errors: dict[str, str]):
        super().__init__("; ".join(f"{k}: {v}" for k, v in errors.items()))
        self.errors = errors


def model_path() -> Path:
    return Path(os.environ.get("SALARY_MODEL_PATH", DEFAULT_MODEL_PATH))


def load_bundle(path: Path | str | None = None, reload: bool = False) -> dict:
    p = Path(path) if path else model_path()
    key = str(p)
    if reload or key not in _cache:
        if not p.is_file():
            raise ModelNotAvailableError(
                f"Model file not found at {p}. Run `python train_model.py` first.")
        try:
            _cache[key] = joblib.load(p)
        except Exception as exc:  # corrupt file, incompatible sklearn version, ...
            log.exception("Failed to load model from %s", p)
            raise ModelNotAvailableError(f"Model file could not be loaded: {exc}") from exc
    return _cache[key]


def get_metadata(path: Path | str | None = None) -> dict:
    return load_bundle(path)["metadata"]


def validate_profile(raw: dict, metadata: dict) -> tuple[dict, list[str]]:
    """Return (clean_profile, warnings) or raise ProfileValidationError."""
    errors: dict[str, str] = {}
    warnings: list[str] = []
    clean: dict = {}

    # Experience: required, finite number within 0..MAX_EXPERIENCE
    value = raw.get("experience_years")
    if value is None or str(value).strip() == "":
        errors["experience_years"] = "Experience is required."
    else:
        try:
            exp = float(str(value).strip())
            if not math.isfinite(exp):
                raise ValueError
        except ValueError:
            errors["experience_years"] = "Experience must be a valid number."
        else:
            if exp < 0 or exp > F.MAX_EXPERIENCE:
                errors["experience_years"] = f"Experience must be between 0 and {F.MAX_EXPERIENCE:g} years."
            else:
                clean["experience_years"] = exp
                lo, hi = metadata["experience_range"]
                if exp > hi:
                    warnings.append(
                        f"Experience of {exp:g} years is above anything in the training data "
                        f"(max {hi:g}); the estimate is an extrapolation and less reliable.")

    # Categorical fields: required, case-insensitive match against training categories
    for col in F.CATEGORICAL:
        label = FIELD_LABELS[col]
        value = raw.get(col)
        if value is None or not str(value).strip():
            errors[col] = f"{label} is required."
            continue
        lookup = {c.lower(): c for c in metadata["categories"][col]}
        canon = lookup.get(str(value).strip().lower())
        if canon is None:
            errors[col] = f"'{str(value).strip()[:60]}' is not a {label.lower()} the model was trained on."
        else:
            clean[col] = canon

    # Skills: optional; unknown skills are ignored with a warning
    known, unknown = F.parse_skills(raw.get("skills"))
    clean["skills"] = ";".join(known)
    if unknown:
        warnings.append("Ignored skills the model does not use: " + ", ".join(unknown[:5]))

    if errors:
        raise ProfileValidationError(errors)

    if "job_title" in clean and "department" in clean:
        if f"{clean['job_title']}|{clean['department']}" not in set(metadata["known_title_department_pairs"]):
            warnings.append("This job title and department combination does not appear in the training "
                            "data, so the estimate may be less reliable.")
    return clean, warnings


def predict_salary(raw: dict, path: Path | str | None = None) -> dict:
    bundle = load_bundle(path)
    meta = bundle["metadata"]
    clean, warnings = validate_profile(raw, meta)
    frame = F.build_feature_frame(pd.DataFrame([clean]))
    annual = float(bundle["pipeline"].predict(frame)[0])
    annual = max(annual, 0.0)
    return {
        "annual_salary_inr": int(round(annual, -2)),
        "monthly_salary_inr": int(round(annual / 12, -2)),
        "profile": clean,
        "warnings": warnings,
        "model_name": meta["model_name"],
        "model_version": meta["model_version"],
        "typical_error_inr": int(round(meta["test_mae"], -2)),  # held-out MAE, not a confidence interval
        "predicted_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
