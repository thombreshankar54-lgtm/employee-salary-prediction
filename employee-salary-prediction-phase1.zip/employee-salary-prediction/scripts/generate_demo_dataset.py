"""Generate the SYNTHETIC demo salary dataset (data/salary_dataset.csv).

This data is artificial. Salaries come from a hand-written formula plus random
noise, NOT from real surveys, so a model trained on it only learns that formula.
Replace data/salary_dataset.csv with real data for any real-world use.

A few duplicate and invalid rows are injected on purpose so the cleaning step in
train_model.py has something real to do. Run: python scripts/generate_demo_dataset.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from features import SKILLS, TARGET  # noqa: E402

SEED = 2024
N_ROWS = 4000
OUT = Path(__file__).resolve().parents[1] / "data" / "salary_dataset.csv"
LAKH = 100_000

# title -> (department, base annual salary in lakh INR for a fresher, is_manager)
TITLES = {
    "Software Engineer": ("Engineering", 7.0, False),
    "DevOps Engineer": ("Engineering", 8.0, False),
    "QA Engineer": ("Engineering", 5.0, False),
    "Engineering Manager": ("Engineering", 20.0, True),
    "Data Analyst": ("Data & Analytics", 5.5, False),
    "Data Scientist": ("Data & Analytics", 10.0, False),
    "ML Engineer": ("Data & Analytics", 12.0, False),
    "BI Developer": ("Data & Analytics", 6.5, False),
    "HR Executive": ("Human Resources", 3.5, False),
    "Talent Acquisition Specialist": ("Human Resources", 4.5, False),
    "HR Manager": ("Human Resources", 10.0, True),
    "Accountant": ("Finance", 3.5, False),
    "Financial Analyst": ("Finance", 6.0, False),
    "Finance Manager": ("Finance", 14.0, True),
    "Digital Marketing Specialist": ("Marketing", 4.5, False),
    "Content Strategist": ("Marketing", 4.0, False),
    "Marketing Manager": ("Marketing", 12.0, True),
    "Sales Executive": ("Sales", 3.5, False),
    "Account Manager": ("Sales", 6.0, False),
    "Sales Manager": ("Sales", 12.0, True),
    "Operations Analyst": ("Operations", 4.5, False),
    "Supply Chain Analyst": ("Operations", 5.0, False),
    "Project Manager": ("Operations", 12.0, True),
    "UI/UX Designer": ("Design", 6.0, False),
    "Product Designer": ("Design", 8.0, False),
    "Product Manager": ("Product", 15.0, True),
    "Business Analyst": ("Product", 7.0, False),
}

# name -> (sampling probability, salary multiplier)
EDUCATION = {"High School": (0.04, 0.85), "Diploma": (0.08, 0.92), "Bachelor's": (0.55, 1.0),
             "Master's": (0.28, 1.12), "PhD": (0.05, 1.25)}
COMPANY = {"Startup (1-50)": (0.2, 0.92), "Small (51-200)": (0.2, 0.95),
           "Medium (201-1000)": (0.25, 1.0), "Large (1001-10000)": (0.2, 1.1),
           "Enterprise (10000+)": (0.15, 1.2)}
EMPLOYMENT = {"Full-time": (0.8, 1.0), "Contract": (0.1, 1.1), "Part-time": (0.06, 0.55),
              "Internship": (0.04, 0.35)}
LOCATION = {"Bengaluru": 1.15, "Mumbai": 1.12, "Delhi NCR": 1.08, "Hyderabad": 1.05, "Pune": 1.0,
            "Remote": 1.0, "Chennai": 0.98, "Kolkata": 0.88, "Ahmedabad": 0.88, "Jaipur": 0.82}
INDUSTRY = {"IT Services": 1.0, "Product / SaaS": 1.15, "Banking & Finance": 1.1, "Healthcare": 0.97,
            "E-commerce": 1.08, "Manufacturing": 0.92, "Education": 0.8, "Consulting": 1.08,
            "Telecom": 0.98}
DEPT_SKILLS = {
    "Engineering": ["Python", "Java", "JavaScript", "SQL", "Cloud Computing", "Cybersecurity"],
    "Data & Analytics": ["Python", "SQL", "Excel", "Machine Learning", "Data Analysis", "Cloud Computing"],
    "Human Resources": ["Excel", "Communication", "Leadership", "Data Analysis"],
    "Finance": ["Excel", "SQL", "Data Analysis", "Communication"],
    "Marketing": ["Communication", "Data Analysis", "Excel", "Leadership"],
    "Sales": ["Communication", "Leadership", "Excel"],
    "Operations": ["Excel", "Project Management", "Data Analysis", "Leadership"],
    "Design": ["Communication", "JavaScript", "Project Management"],
    "Product": ["Project Management", "Data Analysis", "SQL", "Communication", "Leadership"],
}
SKILL_BONUS = {"Python": .03, "SQL": .02, "Excel": .01, "Java": .03, "JavaScript": .02,
               "Machine Learning": .07, "Data Analysis": .02, "Cloud Computing": .05,
               "Project Management": .03, "Communication": .01, "Leadership": .03,
               "Cybersecurity": .05}
assert set(SKILL_BONUS) == set(SKILLS)


def _pick(rng, table):
    keys = list(table)
    probs = np.array([v[0] for v in table.values()], float)
    return keys[rng.choice(len(keys), p=probs / probs.sum())]


def generate(n=N_ROWS, seed=SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    titles = list(TITLES)
    rows = []
    for _ in range(n):
        title = titles[rng.integers(len(titles))]
        dept, base, is_mgr = TITLES[title]
        emp = _pick(rng, EMPLOYMENT)
        if emp == "Internship":
            exp = float(rng.choice([0.0, 0.5, 1.0]))
        elif is_mgr:
            exp = round(rng.uniform(4, 24) * 2) / 2
        else:
            exp = round(float(np.clip(rng.gamma(2.0, 3.0), 0, 30)) * 2) / 2
        edu, size = _pick(rng, EDUCATION), _pick(rng, COMPANY)
        loc, ind = str(rng.choice(list(LOCATION))), str(rng.choice(list(INDUSTRY)))
        relevant = DEPT_SKILLS[dept]
        k = min(len(relevant), int(rng.integers(1, 5)))
        skills = [str(s) for s in rng.choice(relevant, size=k, replace=False)]
        if rng.random() < 0.3:
            extra = str(rng.choice(SKILLS))
            if extra not in skills:
                skills.append(extra)
        skill_mult = min(float(np.prod([1 + SKILL_BONUS[s] for s in skills])), 1.3)
        salary = (base * LAKH * (1 + 0.12 * exp ** 0.85) * EDUCATION[edu][1] * COMPANY[size][1]
                  * EMPLOYMENT[emp][1] * LOCATION[loc] * INDUSTRY[ind] * skill_mult
                  * rng.lognormal(0, 0.10))
        rows.append({"experience_years": exp, "education": edu, "job_title": title,
                     "department": dept, "skills": ";".join(skills),
                     "company_size": size, "employment_type": emp, "location": loc,
                     "industry": ind, TARGET: int(round(salary, -3))})
    df = pd.DataFrame(rows)

    # Deliberate imperfections so the cleaning pipeline is exercised.
    for col in ["education", "location", "industry"]:
        df.loc[rng.choice(n, size=int(0.01 * n), replace=False), col] = np.nan
    bad_exp = df.sample(6, random_state=seed).copy()
    bad_exp["experience_years"] = [-1, -2, -3, -1, -5, -2]
    bad_sal = df.sample(3, random_state=seed + 1).copy()
    bad_sal[TARGET] = 0
    dups = df.sample(25, random_state=seed + 2)
    return (pd.concat([df, dups, bad_exp, bad_sal])
            .sample(frac=1, random_state=seed).reset_index(drop=True))


if __name__ == "__main__":
    data = generate()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(OUT, index=False)
    print(f"Wrote {len(data)} rows to {OUT}")
