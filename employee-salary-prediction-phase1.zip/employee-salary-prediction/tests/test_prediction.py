import json
import unittest

import features as F
import predict
from tests.helpers import PROFILE, trained


class PredictionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = trained()

    def test_prediction_is_positive_and_complete(self):
        r = predict.predict_salary(PROFILE, self.t["model"])
        self.assertGreater(r["annual_salary_inr"], 0)
        self.assertAlmostEqual(r["monthly_salary_inr"], r["annual_salary_inr"] / 12, delta=100)
        for key in ("model_name", "model_version", "predicted_at", "profile", "typical_error_inr"):
            self.assertIn(key, r)

    def test_prediction_is_deterministic(self):
        a = predict.predict_salary(PROFILE, self.t["model"])["annual_salary_inr"]
        b = predict.predict_salary(PROFILE, self.t["model"])["annual_salary_inr"]
        self.assertEqual(a, b)

    def test_more_experience_raises_estimate(self):
        junior = predict.predict_salary({**PROFILE, "experience_years": "0"}, self.t["model"])
        senior = predict.predict_salary({**PROFILE, "experience_years": "15"}, self.t["model"])
        self.assertGreater(senior["annual_salary_inr"], junior["annual_salary_inr"])

    def test_missing_model_file_raises_clear_error(self):
        with self.assertRaises(predict.ModelNotAvailableError):
            predict.load_bundle(self.t["tmp"] / "nope.joblib", reload=True)

    def test_metrics_file_is_real_and_consistent(self):
        m = json.loads(self.t["metrics_path"].read_text())
        self.assertEqual(m["train_size"] + m["test_size"], m["n_rows_clean"])
        self.assertAlmostEqual(m["test_size"] / m["n_rows_clean"], 0.2, places=2)
        self.assertEqual(m["selected_test"], m["models"][m["model_name"]]["test"])
        for name in ("Linear Regression", "Random Forest"):
            self.assertEqual(set(m["models"][name]["test"]), {"mae", "rmse", "r2"})

    def test_no_target_leakage(self):
        self.assertNotIn(F.TARGET, F.FEATURE_COLUMNS)
        meta = predict.get_metadata(self.t["model"])
        self.assertNotIn(F.TARGET, meta["feature_columns"])

    def test_training_is_reproducible(self):
        import train_model
        from tests.helpers import ROOT
        again = train_model.train(ROOT / "data" / "salary_dataset.csv", self.t["tmp"] / "b.joblib",
                                  self.t["tmp"] / "b.json", n_estimators=40, cv_folds=3)
        self.assertEqual(again["selected_test"], self.t["metrics"]["selected_test"])


if __name__ == "__main__":
    unittest.main()
