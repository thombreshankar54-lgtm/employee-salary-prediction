"""Train a small model once into a temp dir so tests never touch the real artifacts."""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import train_model  # noqa: E402

_state = {}


def trained():
    if not _state:
        tmp = Path(tempfile.mkdtemp(prefix="salary_test_"))
        model, metrics = tmp / "m.joblib", tmp / "metrics.json"
        _state.update(model=model, metrics_path=metrics, tmp=tmp,
                      metrics=train_model.train(ROOT / "data" / "salary_dataset.csv", model, metrics,
                                                n_estimators=40, cv_folds=3))
    return _state


PROFILE = {"experience_years": "5", "education": "Bachelor's", "job_title": "Software Engineer",
           "department": "Engineering", "skills": "Python; SQL", "company_size": "Medium (201-1000)",
           "employment_type": "Full-time", "location": "Pune", "industry": "IT Services"}
