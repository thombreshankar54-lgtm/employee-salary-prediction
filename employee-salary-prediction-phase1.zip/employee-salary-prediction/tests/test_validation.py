import unittest

import pandas as pd

import features as F
import predict
from tests.helpers import PROFILE, trained


class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.meta = predict.get_metadata(trained()["model"])

    def errors(self, **changes):
        with self.assertRaises(predict.ProfileValidationError) as ctx:
            predict.validate_profile({**PROFILE, **changes}, self.meta)
        return ctx.exception.errors

    def test_valid_profile_passes(self):
        clean, warnings = predict.validate_profile(PROFILE, self.meta)
        self.assertEqual(clean["skills"], "Python;SQL")
        self.assertEqual(warnings, [])

    def test_invalid_experience_values_rejected(self):
        for bad in ("-1", "abc", "", "nan", "inf", "51", None):
            self.assertIn("experience_years", self.errors(experience_years=bad), msg=repr(bad))

    def test_every_required_field_is_enforced(self):
        for col in F.CATEGORICAL:
            self.assertIn(col, self.errors(**{col: ""}))
            self.assertIn(col, self.errors(**{col: None}))

    def test_unknown_category_rejected_not_silently_accepted(self):
        self.assertIn("location", self.errors(location="Atlantis"))

    def test_category_match_is_case_insensitive(self):
        clean, _ = predict.validate_profile({**PROFILE, "location": " pune "}, self.meta)
        self.assertEqual(clean["location"], "Pune")

    def test_unknown_skill_is_ignored_with_warning(self):
        clean, warnings = predict.validate_profile({**PROFILE, "skills": "Python, Juggling"}, self.meta)
        self.assertEqual(clean["skills"], "Python")
        self.assertTrue(any("Juggling" in w for w in warnings))

    def test_empty_skills_allowed(self):
        clean, _ = predict.validate_profile({**PROFILE, "skills": ""}, self.meta)
        self.assertEqual(clean["skills"], "")

    def test_unseen_title_department_pair_warns(self):
        _, warnings = predict.validate_profile({**PROFILE, "department": "Finance"}, self.meta)
        self.assertTrue(any("combination" in w for w in warnings))

    def test_clean_dataset_removes_bad_rows(self):
        raw = pd.DataFrame([
            {**PROFILE, "annual_salary_inr": 900000},
            {**PROFILE, "annual_salary_inr": 900000},                       # duplicate
            {**PROFILE, "experience_years": -2, "annual_salary_inr": 1},     # bad experience
            {**PROFILE, "annual_salary_inr": 0},                             # bad salary
        ])
        clean, report = F.clean_dataset(raw)
        self.assertEqual(len(clean), 1)
        self.assertEqual(report["duplicates_removed"], 1)

    def test_clean_dataset_rejects_missing_columns(self):
        with self.assertRaises(ValueError):
            F.clean_dataset(pd.DataFrame({"experience_years": [1]}))


if __name__ == "__main__":
    unittest.main()
