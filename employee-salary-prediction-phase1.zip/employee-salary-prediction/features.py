"""Shared feature schema and data cleaning.

Both ``train_model.py`` and ``predict.py`` import from this module, so the
training pipeline and the prediction form are guaranteed to use exactly the
same features and the same skill encoding.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

TARGET = "annual_salary_inr"
CURRENCY = "INR"

CATEGORICAL = [
    "education",
    "job_title",
    "department",
    "company_size",
    "employment_type",
    "location",
    "industry",
]

# Fixed skill vocabulary. Each skill becomes one 0/1 column.
SKILLS = [
    "Python", "SQL", "Excel", "Java", "JavaScript", "Machine Learning",
    "Data Analysis", "Cloud Computing", "Project Management",
    "Communication", "Leadership", "Cybersecurity",
]


def skill_column(skill: str) -> str:
    return "skill_" + re.sub(r"[^a-z0-9]+", "_", skill.lower()).strip("_")


SKILL_COLUMNS = [skill_column(s) for s in SKILLS]
NUMERIC = ["experience_years", "skill_count"]
FEATURE_COLUMNS = NUMERIC + CATEGORICAL + SKILL_COLUMNS

# Columns expected in the raw dataset CSV (also used for employee CSV import).
RAW_COLUMNS = ["experience_years", "education", "job_title", "department",
               "skills", "company_size", "employment_type", "location",
               "industry", TARGET]

MAX_EXPERIENCE = 50.0
MAX_SALARY = 50_000_000  # 5 crore INR: anything above is treated as invalid

_SKILL_LOOKUP = {s.lower(): s for s in SKILLS}


def parse_skills(value) -> tuple[list[str], list[str]]:
    """Split a skills value (str or list) into (known, unknown) canonical lists."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return [], []
    if isinstance(value, str):
        parts = re.split(r"[;,|]", value)
    else:
        parts = list(value)
    known, unknown = [], []
    for part in parts:
        p = str(part).strip()
        if not p:
            continue
        canon = _SKILL_LOOKUP.get(p.lower())
        target = known if canon else unknown
        item = canon or p
        if item not in target:
            target.append(item)
    return known, unknown


def _clean_text(series: pd.Series) -> pd.Series:
    out = series.astype(object).where(series.notna(), np.nan)
    return out.map(lambda v: v.strip() if isinstance(v, str) and v.strip() else np.nan)


def clean_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Remove duplicates and invalid rows; return (clean_df, report)."""
    missing = [c for c in RAW_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    df = df[RAW_COLUMNS].copy()
    report = {"rows_in": int(len(df))}

    for col in CATEGORICAL:
        df[col] = _clean_text(df[col])
    df["skills"] = df["skills"].fillna("").astype(str)
    df["experience_years"] = pd.to_numeric(df["experience_years"], errors="coerce")
    df[TARGET] = pd.to_numeric(df[TARGET], errors="coerce")

    before = len(df)
    df = df.drop_duplicates()
    report["duplicates_removed"] = int(before - len(df))

    before = len(df)
    df = df[df[TARGET].notna()]
    report["missing_target_removed"] = int(before - len(df))

    before = len(df)
    df = df[(df[TARGET] > 0) & (df[TARGET] <= MAX_SALARY)]
    report["invalid_salary_removed"] = int(before - len(df))

    before = len(df)
    df = df[df["experience_years"].between(0, MAX_EXPERIENCE)]
    report["invalid_experience_removed"] = int(before - len(df))

    report["missing_categorical_cells_kept_for_imputation"] = int(df[CATEGORICAL].isna().sum().sum())
    report["rows_out"] = int(len(df))
    return df.reset_index(drop=True), report


def build_feature_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Turn cleaned/validated rows into the exact model input frame."""
    out = pd.DataFrame(index=df.index)
    out["experience_years"] = pd.to_numeric(df["experience_years"], errors="coerce")
    sets = df["skills"].map(lambda v: set(parse_skills(v)[0]))
    out["skill_count"] = sets.map(len)
    for col in CATEGORICAL:
        out[col] = df[col].astype(object).where(df[col].notna(), np.nan)
    for skill, col in zip(SKILLS, SKILL_COLUMNS):
        out[col] = sets.map(lambda s, k=skill: int(k in s))
    return out[FEATURE_COLUMNS]
